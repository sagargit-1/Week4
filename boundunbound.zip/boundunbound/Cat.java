package com.mycom.collections.boundunbound;

public class Cat extends Animal { 
	   Cat(String name) {
		      super(name);
		   }
		}
