package com.mycom.collections.boundunbound;

public class RedCat extends Cat {
	   RedCat(String name) {
		      super(name);
		   }
}
