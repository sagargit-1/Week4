package com.mycom.collections.boundunbound;

public class Animal {
	String name;
	   Animal(String name) { 
	      this.name = name;
	   }
	   public String toString() { 
	      return name;
	   }
}
