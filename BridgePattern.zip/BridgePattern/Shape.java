package com.mycom.designpatterns.bridge;

public interface Shape {
	    void draw();
	}


