package com.mycom.designpatterns.bridge;

public interface Color {
	void applyColor();
}
