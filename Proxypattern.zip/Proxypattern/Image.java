package com.mycom.designpatterns.proxy;

public interface Image {
	void display();
}
