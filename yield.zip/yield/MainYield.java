package com.mycom.threads.yield;

public class MainYield {
	public static void main(String[] args) {
		MyThread t1 = new MyThread();
		MyThread t2 = new MyThread();
	
		// this will call run() method
		t1.start();
		t2.start();
		for (int i = 0; i < 3; i++) {
			// Control passes to child thread
			//t1.yield();
			System.out.println(Thread.currentThread().getName() + " in control");
		}
	}
}
