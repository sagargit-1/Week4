package com.mycom.designpatterns.builder;

public class MainUser {

	public static void main(String[] args) {
		User user1 = new User.UserBuilder("Aaslesha", 30)
					.email("aaslesha@example.com")
					.build();

		User user2 = new User.UserBuilder("Bobby", 25)
				    .phone("1234567890")
				    .build();

		// Accessing user1 and user2 attributes
		System.out.println("User 1: " + user1.getName() + ", " + user1.getAge() + ", " + 
						user1.getEmail());
		System.out.println("User 2: " + user2.getName() + ", " + user2.getAge() + ", " +
						user2.getPhone());

	}

}
