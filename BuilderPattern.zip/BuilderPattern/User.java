package com.mycom.designpatterns.builder;

public class User {
	private final String name;
	private final int age;
	private final String email;
	private final String phone;

	private User(UserBuilder builder) {
		this.name = builder.name;
		this.age = builder.age;
		this.email = builder.email;
		this.phone = builder.phone;
	}

	// Getters for all fields (no setters, as User objects are immutable)
	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}

	// Builder class
	public static class UserBuilder {
		private final String name;
		private final int age;
		private String email;
		private String phone;

		public UserBuilder(String name, int age) {
			this.name = name;
			this.age = age;
		}

		public UserBuilder email(String email) {
			this.email = email;
			return this;
		}

		public UserBuilder phone(String phone) {
			this.phone = phone;
			return this;
		}

		public User build() {
			return new User(this);
		}
	}
}
